import React from "react";

function Image(props) {
  return (
    <div>
    <img src={props.image} className="image" onClick={props.handleClick} />

    </div>
  );
}

export default Image;
