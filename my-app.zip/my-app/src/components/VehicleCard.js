import React from "react";
import Image from "./Image";

function VehicleCard(props) {
  const handleClick = () => {
    props.handleClick(props.dato);
  };

  return (
    <div>
      <Image
        image={props.dato.img}
        handleClick={handleClick}
        isSelected={props.isSelected}
      />
      {props.isSelected && (
        <div>
         
        </div>
      )}
    </div>
  );
}

export default VehicleCard;
