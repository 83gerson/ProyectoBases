import React, { useState, useEffect } from "react";
import VehicleCard from "./VehicleCard";
import TitleText from "./TitleText"; 

function FourColumns(props) {
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [shuffledData, setShuffledData] = useState([]);

  useEffect(() => {
    // Mezclar los datos al cargar el componente
    const shuffled = props.datos.sort(() => Math.random() - 0.5);
    setShuffledData(shuffled);
  }, [props.datos]);

  const handleClick = (dato) => {
    setSelectedVehicle(dato);
  };

  return (
    <div>
      <div className="card2">
        {shuffledData.slice(4, 8).map((dato) => (
          <VehicleCard
            key={dato.id}
            dato={dato}
            handleClick={handleClick}
            isSelected={selectedVehicle === dato}
          />
        ))}
      </div>
      <div className="general-info">
        {selectedVehicle && (
          <div>
            <TitleText title={selectedVehicle.title} text={selectedVehicle.text} />
          </div>
        )}
      </div>
    </div>
  );
}

export default FourColumns;
