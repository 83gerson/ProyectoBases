
import React from 'react';
import FourColumns from './components/FourColumns';
import DataJSON from './data/DataJSON';
import './App.css'


class App extends React.Component{ //componente padre
  constructor(props){
    super(props);
    //aqui defino el estado. El padre hace el cambio
    this.state ={
      DataJSON:DataJSON //definimos el estado
    }
  }x

  render(){
    return( //solo puede devolver un elemento, por eso hacemos un div que funcione como contenedor. Aqui devuelve esos componentes
      <div className='App'>
       
         <FourColumns datos={this.state.DataJSON}/>
      </div>
    );
  }
}
export default App;

