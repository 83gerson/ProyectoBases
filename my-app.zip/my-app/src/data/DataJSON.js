const data = [
    {
      id: 1,
      title: 'Ferrari 488',
      text: 'El Ferrari 488 es un automóvil deportivo de motor central producido por el fabricante italiano Ferrari. Es conocido por su potencia y diseño aerodinámico.',
      img: 'https://upload.wikimedia.org/wikipedia/commons/0/06/Ferrari_488_GTB_IMG_4120.jpg',
    },
    {
      id: 2,
      title: 'Porsche 911',
      text: 'El Porsche 911 es un icónico automóvil deportivo fabricado por Porsche. Se destaca por su rendimiento, manejo y diseño clásico.',
      img: 'https://img.remediosdigitales.com/0c433b/porsche-911_carrera_t-2024-1600-06/1366_2000.jpeg',
    },
    {
      id: 3,
      title: 'Mercedes-Benz S-Class',
      text: 'El Mercedes-Benz Clase S es una serie de sedanes de lujo fabricados por la marca alemana Mercedes-Benz. Es reconocido por su lujo, tecnología y comodidad.',
      img: 'https://www.topgear.com/sites/default/files/2022/03/1-Mercedes-S-Class-plug-in.jpg',
    },
    {
      id: 4,
      title: 'BMW M3',
      text: 'El BMW M3 es un sedán deportivo de alto rendimiento fabricado por BMW. Es conocido por su potencia, maniobrabilidad y estilo deportivo.',
      img: 'https://www.bmw.es/content/dam/bmw/common/all-models/m-series/m3-sedan/2023/highlights/bmw-3-series-cs-m-automobiles-sp-desktop.jpg',
    },
    {
      id: 5,
      title: 'Audi R8',
      text: 'El Audi R8 es un automóvil deportivo de motor central fabricado por Audi. Se destaca por su diseño elegante, rendimiento excepcional y tracción en las cuatro ruedas.',
      img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTPedpW8gVPEaM_pcrJqybomrSaqhrRlhdsvTeFH71&s',
    },
    {
      id: 6,
      title: 'Lamborghini Aventador',
      text: 'El Lamborghini Aventador es un automóvil deportivo de alto rendimiento fabricado por la marca italiana Lamborghini. Es conocido por su diseño agresivo y su motor potente.',
      img: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/Geneva_International_Motor_Show_2018%2C_Le_Grand-Saconnex_%281X7A1486%29.jpg/640px-Geneva_International_Motor_Show_2018%2C_Le_Grand-Saconnex_%281X7A1486%29.jpg',
    },
    {
      id: 7,
      title: 'Chevrolet Camaro',
      text: 'El Chevrolet Camaro es un icónico automóvil deportivo fabricado por Chevrolet. Es reconocido por su estilo clásico y su potencia en la carretera.',
      img: 'https://upload.wikimedia.org/wikipedia/commons/2/2f/2019_Chevrolet_Camaro_base%2C_front_11.9.19.jpg',
    },
    {
      id: 8,
      title: 'Ford Mustang',
      text: 'El Ford Mustang es un automóvil deportivo legendario fabricado por Ford. Se destaca por su estilo icónico y su rendimiento emocionante.',
      img: 'https://www.autobild.es/sites/autobild.es/public/dc/fotos/Ford_Mustanch_Mach_1_01_0.jpg',
    },
  ];
  
  export default data;
  